"""piqtree - access the power of IQ-TREE within Python."""


# start delvewheel patch
def _delvewheel_patch_1_10_0():
    import os
    if os.path.isdir(libs_dir := os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir, '.'))):
        os.add_dll_directory(libs_dir)


_delvewheel_patch_1_10_0()
del _delvewheel_patch_1_10_0
# end delvewheel patch

from _piqtree import __iqtree_version__

from piqtree._data import dataset_names, download_dataset
from piqtree.iqtree import (
    ModelFinderResult,
    TreeGenMode,
    build_tree,
    fit_tree,
    jc_distances,
    model_finder,
    nj_tree,
    random_trees,
    robinson_foulds,
)
from piqtree.model import (
    Model,
    available_freq_type,
    available_models,
    available_rate_type,
    make_model,
)

__version__ = "0.4.0"

__all__ = [
    "Model",
    "ModelFinderResult",
    "TreeGenMode",
    "__iqtree_version__",
    "available_freq_type",
    "available_models",
    "available_rate_type",
    "build_tree",
    "dataset_names",
    "download_dataset",
    "fit_tree",
    "jc_distances",
    "make_model",
    "model_finder",
    "nj_tree",
    "random_trees",
    "robinson_foulds",
]